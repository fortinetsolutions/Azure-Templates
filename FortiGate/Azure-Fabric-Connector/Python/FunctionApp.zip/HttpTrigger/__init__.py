import logging

import azure.functions as func

import os, sys

import json

AppID = os.environ['AppID']
AppPassword = os.environ['AppPassword']
TenantID = os.environ['TenantID']
SubscriptionID = os.environ['SubscriptionID']
RGName = os.environ['RGName']

def AccessTokenID():
    print("hello")

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    AccessTokenID()
    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('name')

    if name:
        return func.HttpResponse(f"Hello {name}! {AppID} {AppPassword} {TenantID} {SubscriptionID} {RGName}")
    else:
        return func.HttpResponse(
             "Please pass a name on the query string or in the request body",
             status_code=400
        )
